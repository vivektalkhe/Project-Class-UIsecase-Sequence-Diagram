function validateDate(){

	//alert('Hello');
	
	var EnteredDate = document.hotel.from.value;
	var date = EnteredDate.substring(8,10);
	var month = EnteredDate.substring(5,7);
	var year = EnteredDate.substring(0,4);

	var myDate = new Date(year, month-1, date);
	var today = new Date();
	
	var todate = document.hotel.to.value;
	var date = todate.substring(8,10);
	var month = todate.substring(5,7);
	var year = todate.substring(0,4);

	var todateinp = new Date(year, month-1, date);
	
	if(myDate < today &&  todateinp < today ){
		alert("Please enter proper date");
		window.location("book.jsp");
	}
	else if(myDate > today && todateinp < myDate){
		alert("To Date cannot be less than From Date");
		window.location("book.jsp");
	}
	else if(myDate > today && todateinp < today){
		alert("To Date cannot be less than From today's date");
		window.location("book.jsp");
	}
	else{
		alert("All set");
	}
}